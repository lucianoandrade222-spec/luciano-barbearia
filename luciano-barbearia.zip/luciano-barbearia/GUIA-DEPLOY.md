# 🚀 Guia de Publicação — Luciano Barbearia

Siga os passos **na ordem**. Tempo estimado: 20 minutos.

---

## PARTE 1 — Criar o banco de dados no Firebase

### 1.1 Criar conta e projeto
1. Acesse **https://console.firebase.google.com**
2. Faça login com sua conta Google
3. Clique em **"Adicionar projeto"**
4. Nome do projeto: `luciano-barbearia` → clique **Continuar**
5. Desative o Google Analytics (não precisa) → clique **Criar projeto**
6. Aguarde e clique **Continuar**

### 1.2 Criar o banco de dados (Firestore)
1. No menu lateral, clique em **"Firestore Database"**
2. Clique em **"Criar banco de dados"**
3. Selecione **"Iniciar no modo de teste"** → clique **Próximo**
4. Escolha a região **`southamerica-east1` (São Paulo)** → clique **Ativar**
5. Aguarde o banco ser criado

### 1.3 Pegar as credenciais do Firebase
1. Clique na engrenagem ⚙️ no topo do menu lateral → **"Configurações do projeto"**
2. Role a página até **"Seus apps"**
3. Clique no ícone **`</>`** (Web) para registrar um app
4. Nome do app: `barbearia` → clique **"Registrar app"**
5. Vai aparecer um bloco de código assim:

```js
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "luciano-barbearia.firebaseapp.com",
  projectId: "luciano-barbearia",
  storageBucket: "luciano-barbearia.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};
```

6. **Copie todos esses valores** — você vai precisar no próximo passo.

---

## PARTE 2 — Configurar o site com suas credenciais

1. Abra o arquivo `public/index.html` em um editor de texto  
   *(pode usar o Bloco de Notas no Windows ou TextEdit no Mac)*
2. Encontre esta parte no início do JavaScript:

```js
var firebaseConfig = {
  apiKey: "COLE_AQUI_apiKey",
  authDomain: "COLE_AQUI_authDomain",
  projectId: "COLE_AQUI_projectId",
  storageBucket: "COLE_AQUI_storageBucket",
  messagingSenderId: "COLE_AQUI_messagingSenderId",
  appId: "COLE_AQUI_appId"
};
```

3. Substitua cada `COLE_AQUI_...` pelo valor correspondente que você copiou do Firebase
4. Salve o arquivo

---

## PARTE 3 — Publicar na Vercel

### 3.1 Criar conta na Vercel
1. Acesse **https://vercel.com**
2. Clique em **"Sign Up"** → entre com sua conta **GitHub**  
   *(se não tiver GitHub, crie em https://github.com — é gratuito)*

### 3.2 Subir o projeto
1. Na Vercel, clique em **"Add New Project"**
2. Clique em **"Upload"** (ou arraste a pasta `luciano-barbearia` inteira)
3. Clique em **"Deploy"**
4. Aguarde cerca de 1 minuto
5. Pronto! A Vercel vai te dar um link como:  
   **`https://luciano-barbearia.vercel.app`**

---

## PARTE 4 — Liberar o banco para o site (importante!)

Por padrão o Firebase bloqueia acesso após 30 dias no modo teste.  
Para deixar permanente:

1. No Firebase, vá em **Firestore Database → Regras**
2. Substitua o conteúdo por:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /agendamentos/{doc} {
      allow read, write: if true;
    }
  }
}
```

3. Clique em **"Publicar"**

---

## ✅ Pronto!

Seu site está no ar com:
- ✂️ Agendamentos salvos permanentemente
- 🔴 Horários bloqueados automaticamente
- 📋 Painel de agenda com cancelamento
- 📱 Confirmação via WhatsApp do cliente
- ⚙️ Serviços e preços editáveis

**Dúvidas?** Volte aqui e pergunte — é só falar!
